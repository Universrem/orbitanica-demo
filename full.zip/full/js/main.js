// main.js

'use strict';

import './globe/globe.js';
import './i18n.js';
import './events/panel_buttons.js';
import './userObjects/modal.js';
import './ui/langMenu.js';


