// DEPRECATED: circleRegistry.js
// Логіка реєстру кіл перенесена у full/js/globe/circles.js (id → rec).
// Цей файл залишено як заглушку, щоб уникнути помилок імпорту в старому коді.

console.warn('[deprecated] globe/circleRegistry.js більше не використовується. Використовуйте globe/circles.js');

export default {};
