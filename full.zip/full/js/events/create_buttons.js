// DEPRECATED: events/create_buttons.js
// Делегований обробник для "Створити" перенесений у events/panel_buttons.js.

console.warn('[deprecated] events/create_buttons.js більше не використовується. Обробку кнопки "Створити" див. у events/panel_buttons.js');

export default null;
